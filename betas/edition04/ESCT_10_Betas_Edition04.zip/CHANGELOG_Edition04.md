# ESCT Boxe — Édition 04

1 novembre 2026.

- Page de choix des dix bêtas avec accès direct aux leçons et galas.
- Navigation entre les dix variantes et retour vers le bon comparateur.
- Dix nouvelles citations originales.
- Identifiant de version visible et styles initiaux propres à chaque modèle.
- Images partagées pour éviter dix téléchargements identiques.

Validation : les dix pages affichent 50 leçons et leurs images ; menu et école de boxe vérifiés dans un cadre de 390 px. Informations du club fictives. Agenda conservé au 31 octobre 2026, sans actualisation automatique.
